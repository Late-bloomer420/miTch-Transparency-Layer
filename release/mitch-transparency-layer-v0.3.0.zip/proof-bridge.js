/**
 * @module proof-bridge
 *
 * Pure, zero-dependency AskMI Proof Bridge mapping helper (v0.3).
 * Aligned with @askmi/shared-types/contracts/claim-contract (v1.0.0):
 *   - CLAIM_CONTRACT_VERSION = "1.0.0"
 *   - CANONICAL_CLAIMS = ["birthdate", "age_over_18"]
 *
 * Fail-closed: only high-confidence over-collection patterns emit a canonical
 * minimal-claim suggestion. Unknown, multi-purpose, or domain-specific fields
 * return no suggestion.
 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) {
    module.exports = factory();
  } else {
    root.MitchProofBridge = factory();
  }
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  const PROOF_BRIDGE_VERSION = "0.3.0";
  const CLAIM_CONTRACT_VERSION = "1.0.0";
  const CANONICAL_CLAIMS = Object.freeze(["birthdate", "age_over_18"]);
  const DEFAULT_LOCAL_WALLET_URL = "http://localhost:5174/";

  const VISIBILITY_FIELD_RULES = Object.freeze([
    {
      key: "health",
      pattern: /health|medical|diagnosis|prescription|blood|allerg|medication|ehds/i,
      label: "Health / Medical Attribute",
      layer: "VULNERABLE (High)",
      state: "Detected",
      hint: "Health-related input metadata observed (VULNERABLE layer). Entered values and legal basis were not verified; selective disclosure can reduce raw attribute exposure."
    },
    {
      key: "financial",
      pattern: /iban|bic|cc-|credit|card|bank|salary|tax|ssn/i,
      label: "Financial / Tax Identifier",
      layer: "VULNERABLE (High)",
      state: "Detected",
      hint: "Financial/tax input metadata observed (VULNERABLE layer). Entered values and server handling were not verified; check relying-party context before disclosure."
    },
    {
      key: "secret",
      pattern: /password|passcode|pin|secret/i,
      label: "Shared Secret / Password Input",
      layer: "VULNERABLE (High)",
      state: "Detected",
      hint: "Password/secret input metadata observed (VULNERABLE layer). Hardware-bound AskMI passkeys can avoid reusable shared secrets where supported."
    },
    {
      key: "dob",
      pattern: /birth|dob|bday|dateofbirth|geburtsdatum|geburtstag/i,
      label: "Full Date of Birth (birthdate)",
      layer: "GRUNDVERSORGUNG (Medium)",
      state: "Prompt",
      hint: "DOB-like input metadata observed (GRUNDVERSORGUNG layer). Site purpose was not verified; where only age eligibility is needed, an AskMI age_over_18 predicate is a data-minimizing option.",
      observedOverCollection: Object.freeze(["birthdate"]),
      suggestedMinimalClaims: Object.freeze(["age_over_18"]),
      rationale: "Full date of birth requested; age >= 18 predicate is data-minimizing."
    },
    {
      key: "contact",
      pattern: /phone|tel|mobile|address|street|postal|zip|plz|wohnort/i,
      label: "Address / Phone Contact",
      layer: "GRUNDVERSORGUNG (Medium)",
      state: "Prompt",
      hint: "Contact/address input metadata observed (GRUNDVERSORGUNG layer). Share only when direct contact or physical delivery is intended."
    },
    {
      key: "identity_basic",
      pattern: /given_name|family_name|firstname|lastname|fullname|email|e-mail/i,
      label: "Basic Identity / Email (WELT)",
      layer: "WELT (Low)",
      state: "Not Detected",
      hint: "Basic identity/email input metadata observed (WELT layer). Pairwise pseudonymous identifiers can reduce cross-site correlation where supported."
    }
  ]);

  /**
   * Strip control characters and collapse newlines/whitespace for untrusted page strings.
   * @param {unknown} raw
   * @param {string} fallback
   * @returns {string}
   */
  function sanitizePlainText(raw, fallback) {
    if (typeof raw !== "string") return fallback;
    const cleaned = raw
      .replace(/[\x00-\x1F\x7F]+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 200);
    return cleaned || fallback;
  }

  /**
   * Escape Markdown inline metacharacters so untrusted page-controlled strings
   * (such as document.title) render strictly as inert literal text (#21).
   * @param {unknown} raw
   * @returns {string}
   */
  function escapeMarkdownInline(raw) {
    const clean = sanitizePlainText(String(raw == null ? "" : raw), "");
    return clean.replace(/([\\`*_{}[\]()#+!<>|~])/g, "\\$1");
  }

  /**
   * Sanitize text placed inside single-backtick Markdown code spans (`...`).
   * Inside CommonMark code spans, _, *, [], () are already literal; only backticks
   * and control characters/newlines could break out of the code span.
   */
  function sanitizeCodeSpan(raw) {
    return sanitizePlainText(String(raw == null ? "" : raw), "").replace(/`/g, "'");
  }

  /**
   * Redact a URL or origin string down to scheme + host (+ port) only,
   * stripping credentials, path, query parameters, and fragments (#21).
   * @param {unknown} rawOrigin
   * @returns {string}
   */
  function sanitizeOrigin(rawOrigin) {
    if (typeof rawOrigin !== "string" || !rawOrigin.trim()) return "unknown";
    const trimmed = rawOrigin.trim();
    if (trimmed === "unknown" || trimmed === "unavailable") return trimmed;
    try {
      const parsed = new URL(trimmed);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
        return "unknown";
      }
      return parsed.origin;
    } catch {
      return "unknown";
    }
  }

  /**
   * Classify a single form field descriptor (attributes only, never field values).
   * @param {{ name?: string, id?: string, autocomplete?: string, placeholder?: string, ariaLabel?: string, type?: string }} field
   * @returns {object | null}
   */
  function classifyFieldDescriptor(field) {
    if (!field || typeof field !== "object") return null;
    const type = String(field.type || "").toLowerCase().trim();
    if (type === "hidden" || type === "submit" || type === "button" || type === "reset") {
      return null;
    }

    const attrTokens = [
      field.name,
      field.id,
      field.autocomplete,
      field.placeholder,
      field.ariaLabel
    ]
      .filter(Boolean)
      .join(" ")
      .toLowerCase()
      .trim();

    const combinedToken = [attrTokens, type].filter(Boolean).join(" ").trim();
    if (!combinedToken) return null;

    for (const rule of VISIBILITY_FIELD_RULES) {
      // For DOB: match birth-related tokens (including type="date" when paired with birth tokens).
      // A generic type="date" without birth tokens (e.g. appointment_date) must NOT match DOB.
      const matched = rule.key === "dob"
        ? rule.pattern.test(attrTokens)
        : rule.pattern.test(combinedToken);

      if (matched) {
        const finding = {
          key: rule.key,
          label: rule.label,
          layer: rule.layer,
          state: rule.state,
          hint: rule.hint
        };
        if (
          Array.isArray(rule.suggestedMinimalClaims) &&
          rule.suggestedMinimalClaims.length > 0 &&
          rule.suggestedMinimalClaims.every((c) => CANONICAL_CLAIMS.includes(c) && c !== "birthdate")
        ) {
          finding.observedOverCollection = Array.from(rule.observedOverCollection || []);
          finding.suggestedMinimalClaims = Array.from(rule.suggestedMinimalClaims);
          finding.rationale = rule.rationale;
        }
        return finding;
      }
    }

    return null;
  }

  /**
   * Evaluate a list of field descriptors and return the AskMI Visibility Layer summary
   * plus a fail-closed canonical proofSuggestion when applicable.
   * @param {Array<object>} fieldDescriptors
   */
  function evaluateFieldsForVisibilityAndProof(fieldDescriptors) {
    const counts = {
      vulnerable: 0,
      grundversorgung: 0,
      welt: 0
    };
    const findingsByKey = new Map();

    if (Array.isArray(fieldDescriptors)) {
      for (const desc of fieldDescriptors) {
        const finding = classifyFieldDescriptor(desc);
        if (!finding) continue;

        if (finding.layer === "VULNERABLE (High)") counts.vulnerable += 1;
        else if (finding.layer === "GRUNDVERSORGUNG (Medium)") counts.grundversorgung += 1;
        else counts.welt += 1;

        if (!findingsByKey.has(finding.key)) {
          const entry = {
            key: finding.key,
            label: finding.label,
            layer: finding.layer,
            state: finding.state,
            hint: finding.hint
          };
          if (finding.suggestedMinimalClaims) {
            entry.observedOverCollection = finding.observedOverCollection;
            entry.suggestedMinimalClaims = finding.suggestedMinimalClaims;
            entry.rationale = finding.rationale;
          }
          findingsByKey.set(finding.key, entry);
        }
      }
    }

    let highestLayer = "None Detected";
    if (counts.vulnerable > 0) {
      highestLayer = "VULNERABLE (High)";
    } else if (counts.grundversorgung > 0) {
      highestLayer = "GRUNDVERSORGUNG (Medium)";
    } else if (counts.welt > 0) {
      highestLayer = "WELT (Low)";
    }

    const findings = Array.from(findingsByKey.values());
    const observedSet = new Set();
    const suggestedSet = new Set();
    const rationales = [];

    for (const f of findings) {
      if (Array.isArray(f.suggestedMinimalClaims) && f.suggestedMinimalClaims.length > 0) {
        (f.observedOverCollection || []).forEach((c) => observedSet.add(c));
        f.suggestedMinimalClaims.forEach((c) => {
          if (CANONICAL_CLAIMS.includes(c) && c !== "birthdate") {
            suggestedSet.add(c);
          }
        });
        if (f.rationale) rationales.push(f.rationale);
      }
    }

    const proofSuggestion = suggestedSet.size > 0
      ? {
          version: PROOF_BRIDGE_VERSION,
          contractVersion: CLAIM_CONTRACT_VERSION,
          observedOverCollection: Array.from(observedSet),
          suggestedMinimalClaims: Array.from(suggestedSet),
          rationale: rationales[0] || "Full date of birth requested; age >= 18 predicate is data-minimizing.",
          note: "This is a local suggestion only. No presentation was started. Open your AskMI wallet to create a real proof."
        }
      : null;

    return {
      highestLayer,
      counts,
      findings,
      proofSuggestion
    };
  }

  /**
   * Build the full v0.3 JSON payload for copying/exporting a Proof Suggestion.
   */
  function buildProofSuggestionPayload(proofSuggestion, pageContext, options) {
    if (
      !proofSuggestion ||
      !Array.isArray(proofSuggestion.suggestedMinimalClaims) ||
      proofSuggestion.suggestedMinimalClaims.length === 0
    ) {
      return null;
    }

    const generatedAt =
      (options && typeof options.generatedAt === "string" && options.generatedAt) ||
      new Date().toISOString();

    return {
      askmiProofSuggestion: {
        version: PROOF_BRIDGE_VERSION,
        contractVersion: CLAIM_CONTRACT_VERSION,
        generatedAt,
        page: {
          origin: sanitizeOrigin(pageContext && pageContext.origin),
          title: sanitizePlainText(pageContext && pageContext.title, "Untitled page")
        },
        observedOverCollection: Array.from(proofSuggestion.observedOverCollection || ["birthdate"]),
        suggestedMinimalClaims: Array.from(proofSuggestion.suggestedMinimalClaims),
        rationale:
          proofSuggestion.rationale ||
          "Full date of birth requested; age >= 18 predicate is data-minimizing.",
        note:
          proofSuggestion.note ||
          "This is a local suggestion only. No presentation was started. Open your AskMI wallet to create a real proof."
      }
    };
  }

  /**
   * Build the human-readable Markdown representation of a Proof Suggestion (Item 7, hardened for #21).
   */
  function buildProofSuggestionMarkdown(proofSuggestion, pageContext, options) {
    const payload = buildProofSuggestionPayload(proofSuggestion, pageContext, options);
    if (!payload) return null;
    const s = payload.askmiProofSuggestion;
    const safeOrigin = sanitizeCodeSpan(s.page.origin);
    const safeTitle = escapeMarkdownInline(s.page.title);
    const safeObserved = s.observedOverCollection.map((c) => sanitizeCodeSpan(c)).join(", ");
    const safeSuggested = s.suggestedMinimalClaims.map((c) => sanitizeCodeSpan(c)).join(", ");
    return [
      `# Suggested minimal AskMI proof`,
      `- **Version:** ${escapeMarkdownInline(s.version)} (Claim Contract \`${sanitizeCodeSpan(s.contractVersion)}\`)`,
      `- **Generated At:** ${escapeMarkdownInline(s.generatedAt)}`,
      `- **Page:** \`${safeOrigin}\` (${safeTitle})`,
      `- **Observed Over-Collection:** \`${safeObserved}\``,
      `- **Suggested Minimal Claim(s):** \`${safeSuggested}\``,
      `- **Rationale:** ${escapeMarkdownInline(s.rationale)}`,
      `- **Note:** ${escapeMarkdownInline(s.note)}`
    ].join("\n");
  }

  /**
   * Fail-closed origin check for experimental local wallet deep-links (Item 8).
   * Strictly allows only http://localhost, https://localhost, http://127.0.0.1, or https://127.0.0.1.
   */
  function isAllowedLocalWalletOrigin(urlStr) {
    if (typeof urlStr !== "string" || !urlStr.trim()) return false;
    try {
      const parsed = new URL(urlStr);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
        return false;
      }
      if (parsed.username || parsed.password) {
        return false;
      }
      const host = parsed.hostname.toLowerCase();
      return host === "localhost" || host === "127.0.0.1";
    } catch {
      return false;
    }
  }

  /**
   * Construct a best-effort local wallet deep-link URL when explicitly opted in (Item 8).
   * Returns null if opt-in is not enabled, if the suggestion is missing/invalid, or if the
   * base URL is not a valid localhost/127.0.0.1 origin.
   */
  function buildLocalWalletDeepLink(proofSuggestion, options) {
    if (!options || options.enabled !== true) {
      return null;
    }
    if (
      !proofSuggestion ||
      !Array.isArray(proofSuggestion.suggestedMinimalClaims) ||
      proofSuggestion.suggestedMinimalClaims.length === 0
    ) {
      return null;
    }

    const validClaims = proofSuggestion.suggestedMinimalClaims.filter(
      (c) => CANONICAL_CLAIMS.includes(c) && c !== "birthdate"
    );
    if (validClaims.length === 0) {
      return null;
    }

    const baseUrl = (options && options.baseUrl) || DEFAULT_LOCAL_WALLET_URL;
    if (!isAllowedLocalWalletOrigin(baseUrl)) {
      return null;
    }

    try {
      const target = new URL(baseUrl);
      target.searchParams.set("demo", "wallet");
      target.searchParams.set("proofBridge", PROOF_BRIDGE_VERSION);
      target.searchParams.set("contractVersion", CLAIM_CONTRACT_VERSION);
      target.searchParams.set("suggest", validClaims.join(","));
      const finalHref = target.toString();
      return isAllowedLocalWalletOrigin(finalHref) ? finalHref : null;
    } catch {
      return null;
    }
  }

  return {
    PROOF_BRIDGE_VERSION,
    CLAIM_CONTRACT_VERSION,
    CANONICAL_CLAIMS,
    DEFAULT_LOCAL_WALLET_URL,
    VISIBILITY_FIELD_RULES,
    sanitizePlainText,
    escapeMarkdownInline,
    sanitizeOrigin,
    classifyFieldDescriptor,
    evaluateFieldsForVisibilityAndProof,
    buildProofSuggestionPayload,
    buildProofSuggestionMarkdown,
    isAllowedLocalWalletOrigin,
    buildLocalWalletDeepLink
  };
});
