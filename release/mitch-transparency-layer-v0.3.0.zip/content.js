const collectorStartedAt = Date.now();

const cspObservations = {
  evalBlockedCount: 0,
  totalViolationCount: 0,
  violatedDirectives: new Set()
};

const activeFingerprinting = {
  canvas: false,
  webgl: false,
  audio: false,
  webrtc: false
};

let pushTimer = null;

function scheduleSurfacePush() {
  if (pushTimer) clearTimeout(pushTimer);
  pushTimer = setTimeout(() => {
    pushTimer = null;
    try {
      chrome.runtime.sendMessage({
        type: "MITCH_PAGE_SURFACES",
        payload: collectAllSurfaces()
      });
    } catch {
      // Ignore when background worker is inactive
    }
  }, 250);
}

window.addEventListener("mitch:surface-observed", (event) => {
  try {
    const surface = event && event.detail && event.detail.surface;
    if (surface && Object.prototype.hasOwnProperty.call(activeFingerprinting, surface)) {
      activeFingerprinting[surface] = true;
      scheduleSurfacePush();
    }
  } catch {
    // Ignore custom event errors
  }
});

document.addEventListener("securitypolicyviolation", (event) => {
  try {
    cspObservations.totalViolationCount += 1;
    const directive = event.violatedDirective || event.effectiveDirective || "unknown";
    cspObservations.violatedDirectives.add(directive);
    if (
      event.blockedURI === "eval" ||
      event.blockedURI === "wasm-eval" ||
      (directive.startsWith("script-src") && !event.blockedURI)
    ) {
      cspObservations.evalBlockedCount += 1;
    }
    scheduleSurfacePush();
  } catch {
    // Ignore observer errors
  }
});

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", scheduleSurfacePush, { once: true });
} else {
  scheduleSurfacePush();
}
window.addEventListener("load", scheduleSurfacePush, { once: true });

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "MITCH_COLLECT_SURFACES") return false;

  sendResponse(collectAllSurfaces());
  return true;
});

function collectAllSurfaces() {
  return {
    available: true,
    observationWindowMs: Math.max(0, Date.now() - collectorStartedAt),
    storage: collectStorage(),
    fingerprinting: collectFingerprintingSurfaces(),
    csp: collectCspSurface(),
    visibilityLayer: collectVisibilityLayer(),
    requests: collectVisibleRequests(),
    screen: collectScreen(),
    language: navigator.language || "Unknown",
    timezone: collectTimezone(),
    userAgent: navigator.userAgent || "Unknown"
  };
}

function collectStorage() {
  return {
    localStorage: describeStorage(window.localStorage),
    sessionStorage: describeStorage(window.sessionStorage)
  };
}

function describeStorage(storage) {
  try {
    if (!storage) return "Not Detected";
    const count = storage.length;
    return count > 0 ? `${count} keys` : "Not Detected";
  } catch {
    return "Unavailable";
  }
}

function hasObservedAttr(surface) {
  try {
    return Boolean(
      document.documentElement &&
      document.documentElement.getAttribute(`data-mitch-fp-${surface}`) === "1"
    );
  } catch {
    return false;
  }
}

function collectFingerprintingSurfaces() {
  return {
    canvas: activeFingerprinting.canvas || hasObservedAttr("canvas"),
    webgl: activeFingerprinting.webgl || hasObservedAttr("webgl"),
    audio: activeFingerprinting.audio || hasObservedAttr("audio"),
    webrtc: activeFingerprinting.webrtc || hasObservedAttr("webrtc"),
    evalAttempt: cspObservations.evalBlockedCount > 0
  };
}

function collectCspSurface() {
  try {
    const meta = document.querySelector('meta[http-equiv="Content-Security-Policy" i]');
    const content = meta ? meta.getAttribute("content") || "" : "";
    const hasMetaCsp = Boolean(content.trim());
    const metaAllowsUnsafeEval = /'unsafe-eval'/i.test(content);
    return {
      hasMetaCsp,
      metaBlocksEval: hasMetaCsp && !metaAllowsUnsafeEval,
      evalBlockedCount: cspObservations.evalBlockedCount,
      totalViolationCount: cspObservations.totalViolationCount,
      violatedDirectives: Array.from(cspObservations.violatedDirectives)
    };
  } catch {
    return {
      hasMetaCsp: false,
      metaBlocksEval: false,
      evalBlockedCount: cspObservations.evalBlockedCount,
      totalViolationCount: cspObservations.totalViolationCount,
      violatedDirectives: []
    };
  }
}

/**
 * Passive DOM field inspection aligned with @askmi/layer-resolver VISIBILITY_LAYER_MAP
 * and @askmi/shared-types claim-contract (via MitchProofBridge).
 * Never reads input values (.value) — only inspects field names/types/autocomplete tokens.
 */
function collectVisibilityLayer() {
  const descriptors = [];
  try {
    const fields = document.querySelectorAll("input, select, textarea");
    fields.forEach((el) => {
      descriptors.push({
        name: el.getAttribute("name"),
        id: el.getAttribute("id"),
        autocomplete: el.getAttribute("autocomplete"),
        placeholder: el.getAttribute("placeholder"),
        ariaLabel: el.getAttribute("aria-label"),
        type: el.getAttribute("type")
      });
    });
  } catch {
    // Ignore DOM access errors
  }

  if (typeof globalThis.MitchProofBridge !== "undefined") {
    return globalThis.MitchProofBridge.evaluateFieldsForVisibilityAndProof(descriptors);
  }

  return {
    highestLayer: "None Detected",
    counts: { vulnerable: 0, grundversorgung: 0, welt: 0 },
    findings: [],
    proofSuggestion: null
  };
}

function collectVisibleRequests() {
  try {
    const pageHost = window.location.hostname.toLowerCase();
    const domainCounts = {};
    let totalThirdParty = 0;

    performance.getEntriesByType("resource").forEach((entry) => {
      try {
        const host = new URL(entry.name).hostname.toLowerCase();
        if (host && !sameSite(host, pageHost)) {
          totalThirdParty += 1;
          domainCounts[host] = (domainCounts[host] || 0) + 1;
        }
      } catch {
        return;
      }
    });

    return {
      available: true,
      thirdPartyRequestCount: totalThirdParty,
      thirdPartyDomains: Object.keys(domainCounts).sort(),
      domainCounts
    };
  } catch {
    return {
      available: false,
      thirdPartyRequestCount: 0,
      thirdPartyDomains: [],
      domainCounts: {}
    };
  }
}

function collectScreen() {
  try {
    if (!window.screen) return "Unknown";
    return `${window.screen.width} × ${window.screen.height}`;
  } catch {
    return "Unknown";
  }
}

function collectTimezone() {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || "Unknown";
  } catch {
    return "Unknown";
  }
}

function sameSite(a, b) {
  return registrableApproximation(a) === registrableApproximation(b);
}

function registrableApproximation(hostname) {
  const parts = hostname.toLowerCase().split(".").filter(Boolean);
  if (parts.length <= 2) return parts.join(".");
  return parts.slice(-2).join(".");
}
